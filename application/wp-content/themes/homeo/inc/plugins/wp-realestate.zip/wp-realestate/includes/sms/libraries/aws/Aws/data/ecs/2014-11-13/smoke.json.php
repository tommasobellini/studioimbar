<?php
// This file was auto-generated from sdk-root/src/data/ecs/2014-11-13/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListClusters', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'StopTask', 'input' => [ 'task' => 'xxxxxxxxxxx-xxxxxxxxxxxx-xxxxxxxxxxx', ], 'errorExpectedFromService' => true, ], ],];
