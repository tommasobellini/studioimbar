<?php
// This file was auto-generated from sdk-root/src/data/acm-pca/2017-08-22/paginators-1.json
return [ 'pagination' => [ 'ListCertificateAuthorities' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'result_key' => 'CertificateAuthorities', ], 'ListPermissions' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'result_key' => 'Permissions', ], 'ListTags' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'result_key' => 'Tags', ], ],];
